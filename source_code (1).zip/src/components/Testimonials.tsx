import React from 'react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    quote:
      "The YouWare code generator accelerated our prototype pipeline by 5x. It's like pairing with a senior engineer who never sleeps.",
    name: 'Sasha Kim',
    role: 'Lead Developer, Nebula Labs'
  },
  {
    quote:
      "From quick scripts to production-ready services, the AI suggestions are shockingly accurate and easy to tweak.",
    name: 'Miguel Alvarez',
    role: 'Principal Engineer, ByteForge'
  },
  {
    quote:
      "Our junior developers now onboard in days instead of weeks thanks to the guided explanations and live demos.",
    name: 'Priya Desai',
    role: 'Head of Engineering, Aurora AI'
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-14">
          <span className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800/60 border border-slate-700/50 rounded-full text-sm text-purple-200 uppercase tracking-wide">
            <Quote className="h-4 w-4" /> Loved by engineering teams
          </span>
          <h2 className="mt-6 text-4xl md:text-5xl font-bold text-white">
            Results that speak for themselves
          </h2>
          <p className="mt-4 text-lg text-slate-300 max-w-3xl mx-auto">
            Teams around the world rely on YouWare to ship faster, improve code quality, and explore new ideas without friction.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <article
              key={testimonial.name}
              className="relative h-full p-8 rounded-2xl border border-slate-700/50 bg-slate-900/40 backdrop-blur-sm transition-transform duration-300 hover:-translate-y-2 hover:border-purple-500/60"
              aria-label={`Testimonial from ${testimonial.name}`}
            >
              <div className="absolute -top-5 left-8 inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-blue-600 p-3 shadow-lg shadow-purple-500/30">
                <Quote className="h-5 w-5 text-white" />
              </div>
              <blockquote className="mt-6 text-slate-200 text-lg leading-relaxed">
                “{testimonial.quote}”
              </blockquote>
              <footer className="mt-8">
                <p className="text-white font-semibold">{testimonial.name}</p>
                <p className="text-sm text-slate-400">{testimonial.role}</p>
              </footer>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
