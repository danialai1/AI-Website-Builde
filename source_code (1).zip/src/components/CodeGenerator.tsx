import React, { useState, useCallback } from 'react';
import { generateText, streamText } from 'ai';
import { createOpenAI } from '@ai-sdk/openai';
import toast from 'react-hot-toast';
import { Sparkles, Zap, Bug, TestTube, Eye, Download, Copy, X } from 'lucide-react';

const CodeGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('javascript');
  const [projectType, setProjectType] = useState('web-app');
  const [selectedModel, setSelectedModel] = useState('openai-gpt-4o');
  const [generatedCode, setGeneratedCode] = useState('');
  const [explanation, setExplanation] = useState('');
  const [optimizedCode, setOptimizedCode] = useState('');
  const [codeReview, setCodeReview] = useState('');
  const [unitTests, setUnitTests] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [isReviewing, setIsReviewing] = useState(false);
  const [isGeneratingTests, setIsGeneratingTests] = useState(false);
  const [activeTab, setActiveTab] = useState<'code' | 'explanation' | 'optimized' | 'review' | 'tests'>('code');
  const [useStreaming, setUseStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const [abortController, setAbortController] = useState<AbortController | null>(null);

  const languages = [
    { value: 'javascript', label: 'JavaScript' },
    { value: 'python', label: 'Python' },
    { value: 'typescript', label: 'TypeScript' },
    { value: 'java', label: 'Java' },
    { value: 'cpp', label: 'C++' },
    { value: 'php', label: 'PHP' },
    { value: 'go', label: 'Go' },
    { value: 'rust', label: 'Rust' },
    { value: 'swift', label: 'Swift' },
    { value: 'kotlin', label: 'Kotlin' },
    { value: 'react', label: 'React JSX' },
    { value: 'html', label: 'HTML' }
  ];

  const projectTypes = [
    { value: 'web-app', label: 'Web Application' },
    { value: 'mobile-app', label: 'Mobile App' },
    { value: 'api', label: 'REST API' },
    { value: 'algorithm', label: 'Algorithm' },
    { value: 'data-analysis', label: 'Data Analysis' },
    { value: 'game', label: 'Game Development' },
    { value: 'automation', label: 'Automation Script' },
    { value: 'ml', label: 'Machine Learning' }
  ];

  const aiModels = [
    { value: 'openai-gpt-4o', label: 'GPT-4o (Smart)', icon: '🧠' },
    { value: 'claude-4-sonnet', label: 'Claude Sonnet (Creative)', icon: '🎨' },
    { value: 'gemini-2.5-pro', label: 'Gemini Pro (Tech Expert)', icon: '⚡' },
    { value: 'deepseek-v3', label: 'DeepSeek v3 (Multi-Tool)', icon: '🔧' },
    { value: 'gemini-2.5-flash', label: 'Gemini Flash (Fastest)', icon: '⚡' }
  ];

  const cancelStreaming = useCallback(() => {
    if (abortController) {
      abortController.abort();
      setAbortController(null);
      toast.success('Streaming cancelled');
    }
  }, [abortController]);

  const generateCode = useCallback(async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a description for the code you want to generate');
      return;
    }

    const startTime = Date.now();
    setIsGenerating(true);
    setGeneratedCode('');
    setExplanation('');
    setOptimizedCode('');
    setCodeReview('');
    setUnitTests('');
    setStreamingText('');

    console.log('🚀 Starting code generation:', { 
      prompt: prompt.substring(0, 100) + '...', 
      language: selectedLanguage, 
      projectType,
      model: selectedModel,
      streaming: useStreaming
    });

    try {
      // Validate configuration
      if (!globalThis.ywConfig?.ai_config?.code_generator) {
        console.error('❌ API Error - Code generator configuration not found');
        throw new Error('API Error - Code generator configuration not found');
      }

      const config = globalThis.ywConfig.ai_config.code_generator;
      const systemPrompt = config.system_prompt({
        language: languages.find(l => l.value === selectedLanguage)?.label || selectedLanguage,
        projectType: projectTypes.find(p => p.value === projectType)?.label || projectType,
      });

      const openai = createOpenAI({
        baseURL: 'https://api.youware.com/public/v1/ai',
        apiKey: 'sk-YOUWARE'
      });

      if (useStreaming) {
        // Streaming generation
        const controller = new AbortController();
        setAbortController(controller);

        console.log('🤖 AI API Request (Code Generation - Streaming):', {
          model: selectedModel,
          language: selectedLanguage,
          projectType,
          prompt: prompt.substring(0, 150) + '...',
          parameters: { temperature: config.temperature }
        });

        const { textStream } = await streamText({
          model: openai(selectedModel),
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: `Generate ${selectedLanguage} code for: ${prompt}` }
          ],
          temperature: config.temperature,
          abortSignal: controller.signal
        });

        let fullText = '';
        for await (const chunk of textStream) {
          if (controller.signal.aborted) {
            console.log('🛑 Streaming aborted by user');
            break;
          }
          fullText += chunk;
          setStreamingText(fullText);
        }

        if (!controller.signal.aborted) {
          setGeneratedCode(fullText);
          console.log('✅ AI API Response (Streaming Complete):', {
            model: selectedModel,
            codeLength: fullText.length,
            processingTime: `${Date.now() - startTime}ms`
          });
        }

        setAbortController(null);
      } else {
        // Standard generation
        console.log('🤖 AI API Request (Code Generation):', {
          model: selectedModel,
          language: selectedLanguage,
          projectType,
          prompt: prompt.substring(0, 150) + '...',
          parameters: {
            temperature: config.temperature,
            maxTokens: config.maxTokens
          }
        });

        const { text: code } = await generateText({
          model: openai(selectedModel),
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: `Generate ${selectedLanguage} code for: ${prompt}` }
          ],
          temperature: config.temperature,
          maxTokens: config.maxTokens
        });

        setGeneratedCode(code);

        // Generate explanation
        const explainerConfig = globalThis.ywConfig.ai_config.code_explainer;
        if (explainerConfig) {
          const explainerPrompt = explainerConfig.system_prompt({
            language: languages.find(l => l.value === selectedLanguage)?.label || selectedLanguage
          });

          const { text: explanationText } = await generateText({
            model: openai(explainerConfig.model),
            messages: [
              { role: 'system', content: explainerPrompt },
              { role: 'user', content: `Explain this ${selectedLanguage} code:\n\n${code}` }
            ],
            temperature: explainerConfig.temperature,
            maxTokens: explainerConfig.maxTokens
          });

          setExplanation(explanationText);
        }

        console.log('✅ AI API Response (Code Generation):', {
          model: selectedModel,
          language: selectedLanguage,
          codeLength: code.length,
          explanationLength: explanation.length,
          processingTime: `${Date.now() - startTime}ms`
        });
      }

      toast.success('Code generated successfully!');

    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log('🛑 Generation cancelled by user');
      } else {
        console.error('❌ API Error - Code generation failed:', {
          model: selectedModel,
          language: selectedLanguage,
          error: error.message,
          processingTime: `${Date.now() - startTime}ms`
        });
        toast.error(`API Error - Code generation failed: ${error.message}`);
      }
    } finally {
      setIsGenerating(false);
    }
  }, [prompt, selectedLanguage, projectType, selectedModel, useStreaming, languages, projectTypes]);

  const optimizeCode = useCallback(async () => {
    if (!generatedCode) {
      toast.error('Generate code first before optimizing');
      return;
    }

    const startTime = Date.now();
    setIsOptimizing(true);
    setOptimizedCode('');

    console.log('⚡ Starting code optimization:', { 
      language: selectedLanguage,
      codeLength: generatedCode.length
    });

    try {
      const config = globalThis.ywConfig?.ai_config?.code_optimizer;
      if (!config) {
        throw new Error('API Error - Code optimizer configuration not found');
      }

      const systemPrompt = config.system_prompt({
        language: languages.find(l => l.value === selectedLanguage)?.label || selectedLanguage
      });

      console.log('🤖 AI API Request (Code Optimization):', {
        model: config.model,
        language: selectedLanguage,
        parameters: {
          temperature: config.temperature,
          maxTokens: config.maxTokens
        }
      });

      const openai = createOpenAI({
        baseURL: 'https://api.youware.com/public/v1/ai',
        apiKey: 'sk-YOUWARE'
      });

      const { text } = await generateText({
        model: openai(config.model),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Optimize this ${selectedLanguage} code:\n\n${generatedCode}` }
        ],
        temperature: config.temperature,
        maxTokens: config.maxTokens
      });

      setOptimizedCode(text);
      setActiveTab('optimized');

      console.log('✅ AI API Response (Code Optimization):', {
        model: config.model,
        optimizedLength: text.length,
        processingTime: `${Date.now() - startTime}ms`
      });

      toast.success('Code optimized successfully!');
    } catch (error: any) {
      console.error('❌ API Error - Code optimization failed:', {
        error: error.message,
        processingTime: `${Date.now() - startTime}ms`
      });
      toast.error(`API Error - Optimization failed: ${error.message}`);
    } finally {
      setIsOptimizing(false);
    }
  }, [generatedCode, selectedLanguage, languages]);

  const reviewCode = useCallback(async () => {
    if (!generatedCode) {
      toast.error('Generate code first before reviewing');
      return;
    }

    const startTime = Date.now();
    setIsReviewing(true);
    setCodeReview('');

    console.log('👁️ Starting code review:', { 
      language: selectedLanguage,
      codeLength: generatedCode.length
    });

    try {
      const config = globalThis.ywConfig?.ai_config?.code_reviewer;
      if (!config) {
        throw new Error('API Error - Code reviewer configuration not found');
      }

      const systemPrompt = config.system_prompt({
        language: languages.find(l => l.value === selectedLanguage)?.label || selectedLanguage
      });

      console.log('🤖 AI API Request (Code Review):', {
        model: config.model,
        language: selectedLanguage,
        parameters: {
          temperature: config.temperature,
          maxTokens: config.maxTokens
        }
      });

      const openai = createOpenAI({
        baseURL: 'https://api.youware.com/public/v1/ai',
        apiKey: 'sk-YOUWARE'
      });

      const { text } = await generateText({
        model: openai(config.model),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Review this ${selectedLanguage} code:\n\n${generatedCode}` }
        ],
        temperature: config.temperature,
        maxTokens: config.maxTokens
      });

      setCodeReview(text);
      setActiveTab('review');

      console.log('✅ AI API Response (Code Review):', {
        model: config.model,
        reviewLength: text.length,
        processingTime: `${Date.now() - startTime}ms`
      });

      toast.success('Code reviewed successfully!');
    } catch (error: any) {
      console.error('❌ API Error - Code review failed:', {
        error: error.message,
        processingTime: `${Date.now() - startTime}ms`
      });
      toast.error(`API Error - Review failed: ${error.message}`);
    } finally {
      setIsReviewing(false);
    }
  }, [generatedCode, selectedLanguage, languages]);

  const generateTests = useCallback(async () => {
    if (!generatedCode) {
      toast.error('Generate code first before creating tests');
      return;
    }

    const startTime = Date.now();
    setIsGeneratingTests(true);
    setUnitTests('');

    console.log('🧪 Starting test generation:', { 
      language: selectedLanguage,
      codeLength: generatedCode.length
    });

    try {
      const config = globalThis.ywConfig?.ai_config?.test_generator;
      if (!config) {
        throw new Error('API Error - Test generator configuration not found');
      }

      const systemPrompt = config.system_prompt({
        language: languages.find(l => l.value === selectedLanguage)?.label || selectedLanguage
      });

      console.log('🤖 AI API Request (Test Generation):', {
        model: config.model,
        language: selectedLanguage,
        parameters: {
          temperature: config.temperature,
          maxTokens: config.maxTokens
        }
      });

      const openai = createOpenAI({
        baseURL: 'https://api.youware.com/public/v1/ai',
        apiKey: 'sk-YOUWARE'
      });

      const { text } = await generateText({
        model: openai(config.model),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Generate comprehensive unit tests for this ${selectedLanguage} code:\n\n${generatedCode}` }
        ],
        temperature: config.temperature,
        maxTokens: config.maxTokens
      });

      setUnitTests(text);
      setActiveTab('tests');

      console.log('✅ AI API Response (Test Generation):', {
        model: config.model,
        testsLength: text.length,
        processingTime: `${Date.now() - startTime}ms`
      });

      toast.success('Unit tests generated successfully!');
    } catch (error: any) {
      console.error('❌ API Error - Test generation failed:', {
        error: error.message,
        processingTime: `${Date.now() - startTime}ms`
      });
      toast.error(`API Error - Test generation failed: ${error.message}`);
    } finally {
      setIsGeneratingTests(false);
    }
  }, [generatedCode, selectedLanguage, languages]);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success('Code copied to clipboard!');
  };

  const downloadCode = (code: string, filename: string) => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Code downloaded!');
  };

  const getFileExtension = () => {
    const extensions: Record<string, string> = {
      javascript: 'js',
      python: 'py',
      typescript: 'ts',
      java: 'java',
      cpp: 'cpp',
      php: 'php',
      go: 'go',
      rust: 'rs',
      swift: 'swift',
      kotlin: 'kt',
      react: 'jsx',
      html: 'html'
    };
    return extensions[selectedLanguage] || 'txt';
  };

  return (
    <section className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            AI-Powered Code Generator
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Generate, optimize, review, and test your code with advanced AI models
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-6">
              <h3 className="text-xl font-semibold text-white mb-4">Code Requirements</h3>
              
              <div className="space-y-4">
                {/* AI Model Selection */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    AI Model
                  </label>
                  <select
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {aiModels.map((model) => (
                      <option key={model.value} value={model.value}>
                        {model.icon} {model.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Language Selection */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Programming Language
                  </label>
                  <select
                    value={selectedLanguage}
                    onChange={(e) => setSelectedLanguage(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {languages.map((lang) => (
                      <option key={lang.value} value={lang.value}>
                        {lang.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Project Type */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Project Type
                  </label>
                  <select
                    value={projectType}
                    onChange={(e) => setProjectType(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {projectTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Streaming Toggle */}
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="streaming"
                    checked={useStreaming}
                    onChange={(e) => setUseStreaming(e.target.checked)}
                    className="w-4 h-4 text-purple-600 bg-slate-700 border-slate-600 rounded focus:ring-purple-500"
                  />
                  <label htmlFor="streaming" className="text-sm text-slate-300">
                    Enable Real-time Streaming
                  </label>
                </div>

                {/* Prompt Input */}
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Describe Your Code
                  </label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="E.g., Create a function to calculate fibonacci numbers, build a todo list component, implement a binary search algorithm..."
                    className="w-full h-32 px-4 py-3 bg-slate-700/50 border border-slate-600 rounded-xl text-white placeholder-slate-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                  />
                </div>

                {/* Generate Button */}
                <button
                  onClick={generateCode}
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full px-6 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-semibold text-lg hover:from-purple-700 hover:to-blue-700 disabled:from-slate-600 disabled:to-slate-600 disabled:cursor-not-allowed transition-all duration-300 hover:scale-105 hover:shadow-lg flex items-center justify-center space-x-2"
                >
                  {isGenerating ? (
                    <>
                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span>Generating...</span>
                      {abortController && (
                        <button
                          onClick={cancelStreaming}
                          className="ml-2 px-3 py-1 bg-red-600 rounded-lg hover:bg-red-700"
                        >
                          Cancel
                        </button>
                      )}
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      <span>Generate Code</span>
                    </>
                  )}
                </button>

                {/* Advanced Tools */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={optimizeCode}
                    disabled={!generatedCode || isOptimizing}
                    className="px-3 py-2 bg-slate-700/50 text-slate-300 rounded-lg hover:bg-slate-600/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-1 text-sm"
                  >
                    <Zap className="w-4 h-4" />
                    <span>Optimize</span>
                  </button>
                  
                  <button
                    onClick={reviewCode}
                    disabled={!generatedCode || isReviewing}
                    className="px-3 py-2 bg-slate-700/50 text-slate-300 rounded-lg hover:bg-slate-600/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-1 text-sm"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Review</span>
                  </button>
                  
                  <button
                    onClick={generateTests}
                    disabled={!generatedCode || isGeneratingTests}
                    className="px-3 py-2 bg-slate-700/50 text-slate-300 rounded-lg hover:bg-slate-600/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-1 text-sm"
                  >
                    <TestTube className="w-4 h-4" />
                    <span>Tests</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Output Section */}
          <div className="space-y-6">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 overflow-hidden">
              <div className="flex border-b border-slate-700/50 overflow-x-auto">
                <button
                  onClick={() => setActiveTab('code')}
                  className={`px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === 'code'
                      ? 'bg-purple-600/20 text-purple-300 border-b-2 border-purple-500'
                      : 'text-slate-400 hover:text-slate-300'
                  }`}
                >
                  Generated Code
                </button>
                <button
                  onClick={() => setActiveTab('explanation')}
                  className={`px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === 'explanation'
                      ? 'bg-purple-600/20 text-purple-300 border-b-2 border-purple-500'
                      : 'text-slate-400 hover:text-slate-300'
                  }`}
                >
                  Explanation
                </button>
                <button
                  onClick={() => setActiveTab('optimized')}
                  className={`px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === 'optimized'
                      ? 'bg-purple-600/20 text-purple-300 border-b-2 border-purple-500'
                      : 'text-slate-400 hover:text-slate-300'
                  }`}
                >
                  Optimized
                </button>
                <button
                  onClick={() => setActiveTab('review')}
                  className={`px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === 'review'
                      ? 'bg-purple-600/20 text-purple-300 border-b-2 border-purple-500'
                      : 'text-slate-400 hover:text-slate-300'
                  }`}
                >
                  Review
                </button>
                <button
                  onClick={() => setActiveTab('tests')}
                  className={`px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === 'tests'
                      ? 'bg-purple-600/20 text-purple-300 border-b-2 border-purple-500'
                      : 'text-slate-400 hover:text-slate-300'
                  }`}
                >
                  Unit Tests
                </button>
              </div>

              <div className="relative min-h-[400px]">
                {activeTab === 'code' && (
                  <div>
                    {(generatedCode || streamingText) ? (
                      <div className="relative">
                        <div className="absolute top-4 right-4 flex space-x-2">
                          <button
                            onClick={() => copyCode(generatedCode || streamingText)}
                            className="px-3 py-1 bg-slate-700/50 text-slate-300 text-sm rounded-lg hover:bg-slate-600/50 transition-colors flex items-center space-x-1"
                          >
                            <Copy className="w-4 h-4" />
                            <span>Copy</span>
                          </button>
                          <button
                            onClick={() => downloadCode(generatedCode || streamingText, `code.${getFileExtension()}`)}
                            className="px-3 py-1 bg-slate-700/50 text-slate-300 text-sm rounded-lg hover:bg-slate-600/50 transition-colors flex items-center space-x-1"
                          >
                            <Download className="w-4 h-4" />
                            <span>Download</span>
                          </button>
                        </div>
                        <pre className="p-6 text-sm overflow-x-auto text-slate-300 bg-slate-900/50 rounded-lg">
                          <code className="whitespace-pre-wrap">
                            {streamingText || generatedCode}
                          </code>
                        </pre>
                        {useStreaming && isGenerating && (
                          <div className="px-6 pb-4 flex items-center space-x-2 text-sm text-slate-400">
                            <div className="animate-pulse">●</div>
                            <span>Streaming in progress...</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="p-12 text-center text-slate-400">
                        <div className="text-4xl mb-4">🤖</div>
                        <p>Generated code will appear here...</p>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'explanation' && (
                  <div className="p-6">
                    {explanation ? (
                      <div className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                        {explanation}
                      </div>
                    ) : (
                      <div className="text-center text-slate-400 py-8">
                        <div className="text-4xl mb-4">📚</div>
                        <p>Code explanation will appear here...</p>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'optimized' && (
                  <div>
                    {optimizedCode ? (
                      <div className="relative">
                        <div className="absolute top-4 right-4 flex space-x-2">
                          <button
                            onClick={() => copyCode(optimizedCode)}
                            className="px-3 py-1 bg-slate-700/50 text-slate-300 text-sm rounded-lg hover:bg-slate-600/50 transition-colors flex items-center space-x-1"
                          >
                            <Copy className="w-4 h-4" />
                            <span>Copy</span>
                          </button>
                          <button
                            onClick={() => downloadCode(optimizedCode, `optimized.${getFileExtension()}`)}
                            className="px-3 py-1 bg-slate-700/50 text-slate-300 text-sm rounded-lg hover:bg-slate-600/50 transition-colors flex items-center space-x-1"
                          >
                            <Download className="w-4 h-4" />
                            <span>Download</span>
                          </button>
                        </div>
                        <pre className="p-6 text-sm overflow-x-auto text-slate-300 bg-slate-900/50 rounded-lg">
                          <code className="whitespace-pre-wrap">
                            {optimizedCode}
                          </code>
                        </pre>
                      </div>
                    ) : (
                      <div className="p-12 text-center text-slate-400">
                        <div className="text-4xl mb-4">⚡</div>
                        <p>Click "Optimize" to improve your code</p>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'review' && (
                  <div className="p-6">
                    {codeReview ? (
                      <div className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                        {codeReview}
                      </div>
                    ) : (
                      <div className="text-center text-slate-400 py-8">
                        <div className="text-4xl mb-4">👁️</div>
                        <p>Click "Review" to analyze your code</p>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'tests' && (
                  <div>
                    {unitTests ? (
                      <div className="relative">
                        <div className="absolute top-4 right-4 flex space-x-2">
                          <button
                            onClick={() => copyCode(unitTests)}
                            className="px-3 py-1 bg-slate-700/50 text-slate-300 text-sm rounded-lg hover:bg-slate-600/50 transition-colors flex items-center space-x-1"
                          >
                            <Copy className="w-4 h-4" />
                            <span>Copy</span>
                          </button>
                          <button
                            onClick={() => downloadCode(unitTests, `tests.${getFileExtension()}`)}
                            className="px-3 py-1 bg-slate-700/50 text-slate-300 text-sm rounded-lg hover:bg-slate-600/50 transition-colors flex items-center space-x-1"
                          >
                            <Download className="w-4 h-4" />
                            <span>Download</span>
                          </button>
                        </div>
                        <pre className="p-6 text-sm overflow-x-auto text-slate-300 bg-slate-900/50 rounded-lg">
                          <code className="whitespace-pre-wrap">
                            {unitTests}
                          </code>
                        </pre>
                      </div>
                    ) : (
                      <div className="p-12 text-center text-slate-400">
                        <div className="text-4xl mb-4">🧪</div>
                        <p>Click "Tests" to generate unit tests</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CodeGenerator;
