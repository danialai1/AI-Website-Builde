import React, { useState, useCallback, useRef, useEffect } from 'react';
import { generateText } from 'ai';
import { createOpenAI } from '@ai-sdk/openai';
import toast from 'react-hot-toast';

const LiveDemo: React.FC = () => {
  const [selectedDemo, setSelectedDemo] = useState('calculator');
  const [generatedCode, setGeneratedCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState('');
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const demoTypes = [
    {
      value: 'calculator',
      label: '🧮 Calculator',
      description: 'Interactive calculator with basic operations',
      prompt: 'Create a beautiful calculator with buttons for numbers 0-9, basic operations (+, -, *, /), equals, and clear. Style it with modern CSS.'
    },
    {
      value: 'todo',
      label: '📝 Todo List',
      description: 'Dynamic todo list with add/remove functionality',
      prompt: 'Create a todo list app with input field to add tasks, checkboxes to mark complete, delete buttons, and modern styling.'
    },
    {
      value: 'weather',
      label: '🌤️ Weather Widget',
      description: 'Weather display with animated icons',
      prompt: 'Create a weather widget showing temperature, weather condition, and animated weather icons. Use mock data for demonstration.'
    },
    {
      value: 'timer',
      label: '⏱️ Timer App',
      description: 'Countdown timer with start/stop controls',
      prompt: 'Create a countdown timer with input for minutes/seconds, start/pause/reset buttons, and visual progress indicator.'
    },
    {
      value: 'color-palette',
      label: '🎨 Color Palette',
      description: 'Interactive color picker and palette generator',
      prompt: 'Create a color palette generator with color picker, random palette generation, and color code display (hex, rgb).'
    },
    {
      value: 'chart',
      label: '📊 Data Chart',
      description: 'Interactive data visualization chart',
      prompt: 'Create an interactive bar chart using Canvas or SVG with sample data, hover effects, and animated transitions.'
    }
  ];

  const generateLiveDemo = useCallback(async () => {
    const demo = demoTypes.find(d => d.value === selectedDemo);
    if (!demo) return;

    const startTime = Date.now();
    setIsGenerating(true);
    setGeneratedCode('');
    setExecutionResult('');

    console.log('🚀 Starting live demo generation:', { 
      selectedDemo, 
      demoLabel: demo.label 
    });

    try {
      // Validate configuration
      if (!globalThis.ywConfig?.ai_config?.live_demo) {
        console.error('❌ API Error - Live demo configuration not found');
        throw new Error('API Error - Live demo configuration not found');
      }

      const config = globalThis.ywConfig.ai_config.live_demo;
      const systemPrompt = config.system_prompt({
        language: 'HTML/CSS/JavaScript',
        concept: demo.description,
      });

      console.log('🤖 AI API Request (Live Demo):', {
        model: config.model,
        demo: selectedDemo,
        prompt: demo.prompt.substring(0, 150) + '...',
        systemPrompt: systemPrompt.substring(0, 100) + '...',
        parameters: {
          temperature: config.temperature,
          maxTokens: config.maxTokens
        }
      });

      const openai = createOpenAI({
        baseURL: 'https://api.youware.com/public/v1/ai',
        apiKey: 'sk-YOUWARE'
      });

      const enhancedPrompt = `${demo.prompt}

Requirements:
- Create a complete HTML page with embedded CSS and JavaScript
- Make it fully functional and interactive
- Use modern, attractive styling
- Ensure it works in an iframe
- No external dependencies (use vanilla JavaScript)
- Include smooth animations and transitions
- Make it responsive for different screen sizes

Please provide the complete HTML code:`;

      const { text: code } = await generateText({
        model: openai(config.model),
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: enhancedPrompt }
        ],
        temperature: config.temperature,
        maxTokens: config.maxTokens
      });

      setGeneratedCode(code);

      console.log('✅ AI API Response (Live Demo):', {
        model: config.model,
        demo: selectedDemo,
        codeLength: code.length,
        processingTime: `${Date.now() - startTime}ms`
      });

      toast.success('Live demo generated successfully!');

    } catch (error: any) {
      console.error('❌ API Error - Live demo generation failed:', {
        model: config?.model,
        demo: selectedDemo,
        error: error.message,
        processingTime: `${Date.now() - startTime}ms`
      });
      toast.error(`API Error - Live demo generation failed: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  }, [selectedDemo]);

  const executeDemo = useCallback(() => {
    if (!generatedCode.trim()) {
      toast.error('Please generate code first');
      return;
    }

    setIsExecuting(true);
    setExecutionResult('');

    // Clean and prepare the HTML code
    let cleanCode = generatedCode.trim();
    
    // Remove code block markers if present
    if (cleanCode.startsWith('```html')) {
      cleanCode = cleanCode.replace(/^```html\n?/, '').replace(/\n?```$/, '');
    } else if (cleanCode.startsWith('```')) {
      cleanCode = cleanCode.replace(/^```[a-zA-Z]*\n?/, '').replace(/\n?```$/, '');
    }

    // If it's not a complete HTML document, wrap it
    if (!cleanCode.toLowerCase().includes('<!doctype') && !cleanCode.toLowerCase().includes('<html')) {
      cleanCode = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Demo</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        * { box-sizing: border-box; }
    </style>
</head>
<body>
    ${cleanCode}
</body>
</html>`;
    }

    // Execute in iframe
    if (iframeRef.current) {
      const iframe = iframeRef.current;
      const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
      
      if (iframeDoc) {
        iframeDoc.open();
        iframeDoc.write(cleanCode);
        iframeDoc.close();
        
        setExecutionResult('Demo executed successfully!');
        toast.success('Demo is now running live!');
      }
    }

    setIsExecuting(false);
  }, [generatedCode]);

  const copyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    toast.success('Code copied to clipboard!');
  };

  return (
    <section className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Live Code Demonstrations
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Watch AI-generated code come to life instantly with interactive demos and real-time execution.
          </p>
        </div>

        {/* Demo Selection */}
        <div className="mb-8">
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-6">
            <h3 className="text-xl font-semibold text-white mb-4">Choose a Demo Type</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {demoTypes.map((demo) => (
                <button
                  key={demo.value}
                  onClick={() => setSelectedDemo(demo.value)}
                  className={`p-4 rounded-xl text-left transition-all duration-300 ${
                    selectedDemo === demo.value
                      ? 'bg-purple-600/30 border-2 border-purple-500 text-white'
                      : 'bg-slate-700/50 border-2 border-slate-600 text-slate-300 hover:bg-slate-600/50 hover:border-slate-500'
                  }`}
                >
                  <div className="font-semibold mb-2">{demo.label}</div>
                  <div className="text-sm opacity-80">{demo.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Code Generation */}
          <div className="space-y-6">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-white">Generated Code</h3>
                <div className="flex gap-2">
                  <button
                    onClick={generateLiveDemo}
                    disabled={isGenerating}
                    className="px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg font-medium hover:from-purple-700 hover:to-blue-700 disabled:from-slate-600 disabled:to-slate-600 disabled:cursor-not-allowed transition-all duration-300"
                  >
                    {isGenerating ? (
                      <span className="flex items-center">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        Generating...
                      </span>
                    ) : (
                      'Generate'
                    )}
                  </button>
                  {generatedCode && (
                    <button
                      onClick={copyCode}
                      className="px-4 py-2 bg-slate-700/50 text-slate-300 rounded-lg hover:bg-slate-600/50 transition-colors"
                    >
                      Copy
                    </button>
                  )}
                </div>
              </div>

              <div className="bg-slate-900/50 rounded-xl p-4 max-h-96 overflow-y-auto">
                {generatedCode ? (
                  <pre className="text-sm text-slate-300 whitespace-pre-wrap">
                    <code>{generatedCode}</code>
                  </pre>
                ) : (
                  <div className="text-center text-slate-400 py-8">
                    <div className="text-4xl mb-4">⚡</div>
                    <p>Click Generate to create live demo code...</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Live Execution */}
          <div className="space-y-6">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-white">Live Demo</h3>
                <button
                  onClick={executeDemo}
                  disabled={!generatedCode || isExecuting}
                  className="px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg font-medium hover:from-green-700 hover:to-emerald-700 disabled:from-slate-600 disabled:to-slate-600 disabled:cursor-not-allowed transition-all duration-300"
                >
                  {isExecuting ? 'Executing...' : '▶️ Run Demo'}
                </button>
              </div>

              <div className="bg-white rounded-xl overflow-hidden" style={{ height: '400px' }}>
                <iframe
                  ref={iframeRef}
                  className="w-full h-full border-0"
                  title="Live Demo"
                  sandbox="allow-scripts allow-same-origin"
                />
              </div>

              {executionResult && (
                <div className="mt-4 p-3 bg-green-900/20 border border-green-700/50 rounded-lg text-green-300 text-sm">
                  ✅ {executionResult}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="mt-16 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-slate-800/30 backdrop-blur-sm rounded-xl border border-slate-700/50">
              <div className="text-3xl mb-3">🚀</div>
              <h4 className="text-lg font-semibold text-white mb-2">Instant Execution</h4>
              <p className="text-slate-400 text-sm">Generated code runs immediately in a secure sandbox environment.</p>
            </div>
            <div className="p-6 bg-slate-800/30 backdrop-blur-sm rounded-xl border border-slate-700/50">
              <div className="text-3xl mb-3">🔧</div>
              <h4 className="text-lg font-semibold text-white mb-2">Full Functionality</h4>
              <p className="text-slate-400 text-sm">Complete applications with user interactions and real-time updates.</p>
            </div>
            <div className="p-6 bg-slate-800/30 backdrop-blur-sm rounded-xl border border-slate-700/50">
              <div className="text-3xl mb-3">💡</div>
              <h4 className="text-lg font-semibold text-white mb-2">Learning Tool</h4>
              <p className="text-slate-400 text-sm">Perfect for understanding how code works through live examples.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LiveDemo;