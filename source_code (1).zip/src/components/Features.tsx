import React from 'react';

const Features: React.FC = () => {
  const features = [
    {
      icon: '🚀',
      title: 'Multi-Language Support',
      description: 'Generate code in 20+ programming languages including JavaScript, Python, Java, C++, and more.',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: '⚡',
      title: 'Lightning Fast',
      description: 'Get production-ready code in seconds with our advanced AI models optimized for speed and accuracy.',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: '🎯',
      title: 'Live Demonstrations',
      description: 'See your code in action immediately with interactive previews and real-time execution.',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: '🔧',
      title: 'Smart Optimization',
      description: 'Automatically optimize code for performance, readability, and best practices.',
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: '📚',
      title: 'Code Explanation',
      description: 'Understand every line with detailed explanations and inline comments.',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: '🎨',
      title: 'Multiple AI Models',
      description: 'Choose from GPT-4, Claude, Gemini, and specialized models for different tasks.',
      gradient: 'from-pink-500 to-rose-500'
    }
  ];

  return (
    <section className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Powerful AI Features
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Experience cutting-edge AI capabilities designed to revolutionize how you write and understand code.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative p-8 bg-slate-800/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 hover:border-slate-600 transition-all duration-500 hover:transform hover:-translate-y-2 hover:shadow-2xl"
            >
              {/* Gradient Background Effect */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 rounded-2xl transition-opacity duration-500`} />
              
              <div className="relative z-10">
                <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                
                <h3 className="text-xl font-bold text-white mb-4 group-hover:text-slate-100 transition-colors duration-300">
                  {feature.title}
                </h3>
                
                <p className="text-slate-400 group-hover:text-slate-300 transition-colors duration-300 leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Hover Border Effect */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-500 blur-xl`} />
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { number: '20+', label: 'Languages Supported' },
            { number: '5', label: 'AI Models Available' },
            { number: '<1s', label: 'Average Generation Time' },
            { number: '99%', label: 'Code Accuracy' }
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent mb-2">
                {stat.number}
              </div>
              <div className="text-slate-400 text-sm font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;