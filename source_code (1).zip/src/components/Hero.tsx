import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center text-center">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-500/20 rounded-full blur-2xl animate-pulse delay-1000" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4">
        <div className="mb-8">
          <span className="inline-block px-4 py-2 bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-full text-purple-300 text-sm font-medium mb-6 backdrop-blur-sm border border-purple-500/30">
            🤖 AI-Powered Code Generation
          </span>
        </div>

        <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent leading-tight mb-6">
          Generate Code in
          <span className="block bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
            Any Language
          </span>
        </h1>

        <p className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto mb-12 leading-relaxed">
          Experience the future of programming with our AI code generator. 
          Create production-ready code in multiple programming languages with live demonstrations and instant results.
        </p>

        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16">
          <button className="group relative px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-semibold text-lg overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/25">
            <span className="relative z-10">Start Generating</span>
            <div className="absolute inset-0 bg-gradient-to-r from-purple-700 to-blue-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </button>
          
          <button className="px-8 py-4 text-slate-300 border border-slate-600 rounded-xl hover:bg-slate-800/50 hover:border-slate-500 transition-all duration-300 font-semibold text-lg">
            View Examples
          </button>
        </div>

        {/* Language Support Pills */}
        <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
          {[
            'JavaScript', 'Python', 'React', 'HTML/CSS', 'TypeScript', 
            'Java', 'C++', 'PHP', 'Go', 'Rust', 'Swift', 'Kotlin'
          ].map((lang) => (
            <span 
              key={lang}
              className="px-4 py-2 bg-slate-800/50 text-slate-300 rounded-full text-sm font-medium backdrop-blur-sm border border-slate-700/50 hover:bg-slate-700/50 hover:border-slate-600 transition-all duration-300"
            >
              {lang}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;