import { useState } from 'react'
import { Toaster } from 'react-hot-toast'
import CodeGenerator from './components/CodeGenerator'
import Hero from './components/Hero'
import Features from './components/Features'
import LiveDemo from './components/LiveDemo'
import Testimonials from './components/Testimonials'

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Toaster position="top-right" />
      
      <div className="container mx-auto px-4">
        <Hero />
        <Features />
        <Testimonials />
        <CodeGenerator />
        <LiveDemo />
      </div>
      
      <footer className="bg-slate-800/50 backdrop-blur-sm border-t border-slate-700 mt-20">
        <div className="container mx-auto px-4 py-8 text-center text-slate-300">
          <p>&copy; 2025 AI Code Generator. Powered by Advanced AI Models.</p>
        </div>
      </footer>
    </div>
  )
}

export default App